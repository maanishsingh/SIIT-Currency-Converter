/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SIITCurrency;

/**
 *
 * @author manish
 */
public class CurrencyData {
    public boolean success;
    public String terms;
    public double timestamp;
    public String source;
    Quotes quotes;
    
  public static class Quotes {
      float USDINR;
      float USDAUD;
      float USDCAD;
      float USDPLN;
      float USDMXN;

        @Override
        public String toString() {
            return "Quotes{" + "USDINR=" + USDINR + ", USDAUD=" + USDAUD + ", USDCAD=" + USDCAD + ", USDPLN=" + USDPLN + ", USDMXN=" + USDMXN + '}';
        }
      
      
    }

    @Override
    public String toString() {
        return "CurrencyData{" + "success=" + success + ", terms=" + terms + ", timestamp=" + timestamp + ", source=" + source + ", quotes=" + quotes + '}';
    }
    
}
